package com.project.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    //request code
    final int CAMERA_REQUEST_CODE = 1;
    // ImageView, Button, Textview 선언
    ImageView img;
    Button btnCamera;
    Button btnCheck;
    TextView textView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img = (ImageView) findViewById(R.id.img);
        btnCamera = (Button) findViewById(R.id.btnCamera);
        btnCheck = (Button) findViewById(R.id.btnCheck);

        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Camera Application이 있으면
                if (IsCameraAvailable()) {

                    // Camera Application을 실행한다.
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, CAMERA_REQUEST_CODE);
                }
            }
        });

        btnCheck.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView1 = (TextView) findViewById(R.id.textView1);

                textView1.setText("Red");
            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // 사진찍기 버튼을 누른 후 잘 찍고 돌아왔다면
        if (requestCode == CAMERA_REQUEST_CODE) {
            // 사진을 ImageView에 보여준다.
            Bundle bundle = data.getExtras();
            Bitmap bitmap = (Bitmap) bundle.get("data");
            img.setImageBitmap(bitmap);
        }
    }

    //카메라 유무
    public boolean IsCameraAvailable() {
        PackageManager packageManager = getPackageManager();
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        List<ResolveInfo> list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        return list.size() > 0;
    }
}

